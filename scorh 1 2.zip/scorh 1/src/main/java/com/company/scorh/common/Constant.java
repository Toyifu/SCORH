package com.company.scorh.common;

public final class Constant {
    public static final int SUCCESS=0;
    public static final int ERROR=-1;
    public static final int NEED_LOGIN=10;
}
