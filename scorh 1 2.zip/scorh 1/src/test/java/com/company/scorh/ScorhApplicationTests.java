package com.company.scorh;

import com.company.scorh.dao.UserDao;
import com.company.scorh.domain.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScorhApplicationTests {

    @Autowired
    UserDao userDao;
    @Test
    void contextLoads() {
        User user=userDao.select("bob");
        System.out.println(user);
    }

}
